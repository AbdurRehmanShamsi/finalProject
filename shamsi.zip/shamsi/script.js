
function createBoard(boardSize, numberOfMines) {
    let board = [];
    let mineLocations = getMineLocations(boardSize, numberOfMines);
    for (let x = 0; x < boardSize; x++) {
        let row = [];
        for (let y = 0; y < boardSize; y++) {
            let element = document.createElement('div');
            element.classList.add("hiddentile");

            let tile = {
                element,
                x,
                y,
                mine: mineLocations.some(positionMatch.bind(null, { x, y }))
            };
            row.push(tile);
        }
        board.push(row);
    }
    return board;
}

function markTile(tile) {
    if (tile.element.classList.contains("hiddentile") == false &&
        tile.element.classList.contains("markedtile") == false)
    {
        return;
    }

    if (tile.element.classList.contains("markedtile") == true)
    {
        tile.element.classList.remove("markedtile");
        tile.element.classList.add("hiddentile");
        tile.element.textContent = "";
    } 
    else
    {
        tile.element.classList.add("markedtile");
        tile.element.textContent = "🚩";
    }
}

function revealTile(board, tile) {
    if (tile.element.classList.contains("hiddentile") == false)
    {
        return;
    }

    if (tile.mine)
    {
        tile.element.classList.add("minetile");
        tile.element.textContent = "💣";
        return;
    }
    
    tile.element.classList.remove("hiddentile");
    tile.element.classList.remove("markedtile");
    tile.element.textContent = "";

    tile.element.classList.add("numbertile");

    const adjacentTiles = nearbyTiles(board, tile)
    const mines = adjacentTiles.filter(t => t.mine)
    if (mines.length === 0)
    {
        adjacentTiles.forEach(revealTile.bind(null, board));
    }
    else
    {
        tile.element.textContent = mines.length;
    }
}

function getMineLocations(boardSize, numberOfMines) {
    let mineLocations = [];
    while (mineLocations.length < numberOfMines)
    {
        const location =
        {
            x: Math.floor(Math.random() * boardSize),
            y: Math.floor(Math.random() * boardSize)
        }

        if (!mineLocations.some(positionMatch.bind(null, location)))
        {
            mineLocations.push(location);
        }
    }
    return mineLocations;
}

function positionMatch(a, b) {
    return a.x === b.x && a.y === b.y;
}

function nearbyTiles(board, { x, y }) {
    const tiles = [];
    for (let xOffset = -1; xOffset <= 1; xOffset++)
    {
        for (let yOffset = -1; yOffset <= 1; yOffset++)
        {
            if( board[x + xOffset] && board[x + xOffset][y + yOffset] ){
                let tile = board[x + xOffset][y + yOffset]
                if (tile) tiles.push(tile);   
            }
            
        }
    }
    return tiles;
}

/***********/

let boardSize = 10;
let numberOfMines = 10;
let sec = 0;
let board = createBoard(boardSize, numberOfMines);
let boardElement = document.querySelector(".board");
let messageText = document.querySelector(".subtext");
let time = setInterval( timing, 1000);

board.forEach(row => {
    row.forEach(tile => {
        boardElement.append(tile.element);

        tile.element.addEventListener("click", () => {
            revealTile(board, tile);
            checkGameEnd();
        })

        tile.element.addEventListener("contextmenu", e => {
            e.preventDefault();
            markTile(tile);

            let markedCount = document.querySelectorAll(".markedtile").length;
            let left = numberOfMines - markedCount;
            messageText.textContent = "Mines Left : " + left;

        })
    })
})

boardElement.style.setProperty("--grid", boardSize);
messageText.textContent = "Mines Left : " + numberOfMines;

function checkGameEnd() {
    let win = checkWin()
    let lose = checkLose()

    if (win || lose)
    {
        boardElement.addEventListener("click", stopPropagation, { capture: true });
        boardElement.addEventListener("contextmenu", stopPropagation, { capture: true });
        clearInterval(time);
    }

    if (win)
    {
        messageText.textContent = "Congratulations! You Won 🤩";
        
    }
    if (lose)
    {
        messageText.textContent = "You clicked on a Bomb. Sorry! You Lost 😥";
        board.forEach(row => {
            row.forEach(tile => {
                if (tile.element.classList.contains("markedtile") == true)
                {
                    markTile(tile);
                }
                if (tile.mine)
                {
                    revealTile(board, tile);
                }
            })
        })
    }
}

function stopPropagation(e) {
    e.stopImmediatePropagation()
}

function checkLose() {
    if (document.querySelectorAll(".minetile").length > 0)
    {
        return true;
    }
}

function checkWin() {
    if (document.querySelectorAll(".hiddentile").length === numberOfMines)
    {
        return true;
    }
}

function second ( val )
{
    return val > 9 ? val : "0" + val;
}

function timing()
{
    document.getElementById("timer").innerHTML=(second(parseInt(sec/60,10))).toString() + ':' + (second(++sec%60)).toString();
}
